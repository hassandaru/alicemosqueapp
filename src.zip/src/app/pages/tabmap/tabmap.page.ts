import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'app-tabmap',
    templateUrl: './tabmap.page.html',
    styleUrls: ['./tabmap.page.scss'],
})
export class TabmapPage implements OnInit {

    constructor() {
    }

    ngOnInit() {
    }

}
