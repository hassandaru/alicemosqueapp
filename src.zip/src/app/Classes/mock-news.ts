import {News} from './news';

export const NewsList: News[] = [
    {
        heading: 'Month of Shaban',
        date: '14/04/2019',
        description: 'The month of shaban is the one before ramadan and is an exciting time as people prepare to buy food, schedule iftars and remember what its like to be hungry so we have compassion for the poor.'
    },
    {
        heading: 'Juma scheduled',
        date: '19/04/2019',
        description: 'This is the most blessed day in the week when people gather in congression to worship the one God.'
    }
];
