export class News {
    heading: string;
    date: string;
    description: string;
}
