export class Prayer {
    name: string;
    time: string;
}
